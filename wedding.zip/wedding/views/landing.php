<?php
require '../firebase/firebase.php'; // Pastikan path sesuai

// Ambil data undangan aktif dari Firebase
try {
    $activeInvitationRef = $firebase->getReference('undangan/active_invitation');
    $activeInvitation = $activeInvitationRef->getValue();

    if (!$activeInvitation) {
        die("Tidak ada undangan yang aktif.");
    }
} catch (Exception $e) {
    die("Error: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Undangan Pernikahan</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            color: #333;
            text-align: center;
            padding: 20px;
        }
        .undangan-container {
            max-width: 800px;
            margin: 0 auto;
            background-color: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }
        .undangan-container img {
            width: 100%;
            border-radius: 10px;
        }
        .undangan-container h2 {
            color: #e91e63;
        }
        .details {
            font-size: 18px;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <h1>Selamat datang di Undangan Pernikahan Kami</h1>
    <div class="undangan-container">
        <!-- Foto Pengantin (opsional) -->
        <?php if (!empty($activeInvitation['fotoPengantin'])): ?>
            <img src="<?= htmlspecialchars($activeInvitation['fotoPengantin']) ?>" alt="Foto Pengantin">
        <?php endif; ?>

        <!-- Nama Pengantin -->
        <h2><?= htmlspecialchars($activeInvitation['namaPengantinPria']) ?> & <?= htmlspecialchars($activeInvitation['namaPengantinWanita']) ?></h2>

        <!-- Tanggal Pernikahan -->
        <div class="details">
            <strong>Tanggal Pernikahan:</strong> <?= htmlspecialchars($activeInvitation['tanggalPernikahan']) ?>
        </div>

        <!-- Alamat -->
        <div class="details">
            <strong>Alamat:</strong> <?= htmlspecialchars($activeInvitation['alamat']) ?>
        </div>

        <!-- Tema -->
        <div class="details">
            <strong>Tema Pernikahan:</strong> <?= htmlspecialchars($activeInvitation['tema']) ?>
        </div>
    </div>
</body>
</html>
