<?php
session_start();
require '../firebase/firebase.php';  // Pastikan path sesuai

// Cek apakah user sudah login sebagai admin
if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
    header('Location: login.php');  // Redirect ke login jika bukan admin
    exit();
}

// Ambil data undangan dari Firebase
$undanganRef = $firebase->getReference('undangan');
$data = $undanganRef->getValue();

// Ambil undangan aktif
$activeInvitationRef = $firebase->getReference('undangan/active_invitation');
$activeInvitation = $activeInvitationRef->getValue();

// Jika data tidak ada, inisialisasi dengan array kosong
$data = $data ? $data : [];

// Menangani perubahan undangan aktif
if (isset($_GET['set_active']) && !empty($_GET['set_active'])) {
    $id = $_GET['set_active'];

    if (isset($data[$id])) {
        try {
            // Set undangan aktif
            $activeInvitationRef->set($data[$id]);

            // Redirect kembali ke dashboard dengan pesan sukses
            header('Location: index.php?status=active_set');
            exit();
        } catch (Exception $e) {
            die("Error: " . $e->getMessage());
        }
    } else {
        die("Undangan tidak ditemukan.");
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin</title>
    
    <!-- Bootstrap 5.3.2 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    
    <!-- Custom Styles -->
    <style>
        body {
            background-color: #f4f6f9;
            font-family: 'Inter', sans-serif;
        }
        .dashboard-container {
            background-color: white;
            border-radius: 12px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
            padding: 2rem;
            margin-top: 2rem;
        }
        .table {
            border-radius: 12px;
            overflow: hidden;
        }
        .table thead {
            background-color: #007bff;
            color: white;
        }
        .table-hover tbody tr:hover {
            background-color: rgba(0,123,255,0.075);
            transition: background-color 0.3s ease;
        }
        .btn-action {
            margin-right: 0.25rem;
            margin-bottom: 0.25rem;
        }
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
        }
        .page-header h1 {
            margin-bottom: 0;
            color: #333;
        }
        .status-badge {
            transition: all 0.3s ease;
        }
        .status-badge:hover {
            transform: scale(1.1);
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="dashboard-container">
            <div class="page-header">
                <h1><i class="bi bi-speedometer2 me-2"></i>Dashboard Admin</h1>
                <div>
                    <a href="tambah.php" class="btn btn-primary me-2">
                        <i class="bi bi-plus-circle me-1"></i>Tambah Undangan
                    </a>
                    <a href="logout.php" class="btn btn-danger">
                        <i class="bi bi-box-arrow-right me-1"></i>Logout
                    </a>
                </div>
            </div>

            <!-- Menampilkan pesan jika ada status -->
            <?php if (isset($_GET['status'])): ?>
                <?php if ($_GET['status'] === 'deleted'): ?>
                    <div class="alert alert-success d-flex align-items-center" role="alert">
                        <i class="bi bi-check-circle-fill me-2"></i>
                        <div>Data undangan berhasil dihapus.</div>
                    </div>
                <?php elseif ($_GET['status'] === 'active_set'): ?>
                    <div class="alert alert-success d-flex align-items-center" role="alert">
                        <i class="bi bi-check-circle-fill me-2"></i>
                        <div>Undangan aktif berhasil diatur.</div>
                    </div>
                <?php endif; ?>
            <?php endif; ?>

            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Nama Pengantin Pria</th>
                            <th>Nama Pengantin Wanita</th>
                            <th>Tanggal Pernikahan</th>
                            <th>Alamat</th>
                            <th>Status</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($data as $id => $undangan): ?>
                            <tr>
                                <td><?= htmlspecialchars($undangan['namaPengantinPria']) ?></td>
                                <td><?= htmlspecialchars($undangan['namaPengantinWanita']) ?></td>
                                <td><?= htmlspecialchars($undangan['tanggalPernikahan']) ?></td>
                                <td><?= htmlspecialchars($undangan['alamat']) ?></td>
                                <td>
                                    <?php if ($activeInvitation && $activeInvitation['namaPengantinPria'] === $undangan['namaPengantinPria']): ?>
                                        <span class="badge bg-success status-badge">
                                            <i class="bi bi-check-circle me-1"></i>Aktif
                                        </span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary status-badge">
                                            <i class="bi bi-dash-circle me-1"></i>Tidak Aktif
                                        </span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="edit.php?id=<?= $id ?>" class="btn btn-sm btn-warning btn-action">
                                        <i class="bi bi-pencil me-1"></i>Edit
                                    </a>
                                    <a href="delete.php?id=<?= $id ?>" class="btn btn-sm btn-danger btn-action" 
                                        onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?');">
                                        <i class="bi bi-trash me-1"></i>Hapus
                                    </a>
                                    <?php if (!$activeInvitation || $activeInvitation['namaPengantinPria'] !== $undangan['namaPengantinPria']): ?>
                                        <a href="?set_active=<?= $id ?>" class="btn btn-sm btn-success btn-action"
                                           onclick="return confirm('Jadikan undangan ini sebagai aktif?');">
                                            <i class="bi bi-check-circle me-1"></i>Set Aktif
                                        </a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Bootstrap 5.3.2 JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>