<?php
session_start();
require '../firebase/firebase.php';

// Cek apakah user sudah login sebagai admin
if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
    header('Location: login.php');
    exit();
}

// Pastikan ada parameter id yang dikirim melalui URL
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    try {
        // Ambil data undangan berdasarkan ID
        $undangan = $firebase->getReference("undangan/$id")->getValue();

        if (!$undangan) {
            die("Data tidak ditemukan.");
        }
    } catch (Exception $e) {
        die("Error: " . $e->getMessage());
    }
} else {
    die("ID tidak ditemukan.");
}

// Proses penyimpanan data yang diperbarui
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = [
        "namaPengantinPria" => $_POST['namaPengantinPria'],
        "namaPengantinWanita" => $_POST['namaPengantinWanita'],
        "tanggalPernikahan" => $_POST['tanggalPernikahan'],
        "alamat" => $_POST['alamat'],
        "tema" => $_POST['tema']
    ];

    try {
        // Simpan data yang diperbarui
        $firebase->getReference("undangan/$id")->update($data);

        // Redirect ke halaman utama setelah update
        header("Location: ../admin/index.php?status=updated");
        exit();
    } catch (Exception $e) {
        die("Error: " . $e->getMessage());
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Bootstrap 5.3.2 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">

    <title>Edit Data Undangan</title>

    <style>
        html, body {
            height: 100%;
            margin: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: #f4f6f9;
        }
        .edit-container {
            background-color: white;
            border-radius: 12px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
            padding: 2rem;
            max-width: 600px;
            width: 100%;
        }
        .form-label {
            font-weight: 600;
            color: #495057;
        }
        .form-control:focus {
            border-color: #007bff;
            box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
        }
        .btn-primary {
            transition: all 0.3s ease;
        }
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>
<body>
    <div class="edit-container">
        <h2 class="text-center mb-4">
            <i class="bi bi-pencil-square me-2 text-primary"></i>Edit Undangan
        </h2>

        <form method="POST">
            <div class="row g-3">
                <div class="col-md-6">
                    <label for="namaPengantinPria" class="form-label">Nama Pengantin Pria</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-person"></i></span>
                        <input type="text" class="form-control" id="namaPengantinPria" name="namaPengantinPria"
                               value="<?= htmlspecialchars($undangan['namaPengantinPria']) ?>" required>
                    </div>
                </div>

                <div class="col-md-6">
                    <label for="namaPengantinWanita" class="form-label">Nama Pengantin Wanita</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-person-heart"></i></span>
                        <input type="text" class="form-control" id="namaPengantinWanita" name="namaPengantinWanita"
                               value="<?= htmlspecialchars($undangan['namaPengantinWanita']) ?>" required>
                    </div>
                </div>

                <div class="col-md-6">
                    <label for="tanggalPernikahan" class="form-label">Tanggal Pernikahan</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-calendar-event"></i></span>
                        <input type="date" class="form-control" id="tanggalPernikahan" name="tanggalPernikahan"
                               value="<?= htmlspecialchars($undangan['tanggalPernikahan']) ?>" required>
                    </div>
                </div>

                <div class="col-md-6">
                    <label for="tema" class="form-label">Tema</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-palette"></i></span>
                        <input type="text" class="form-control" id="tema" name="tema"
                               value="<?= htmlspecialchars($undangan['tema']) ?>" required>
                    </div>
                </div>

                <div class="col-12">
                    <label for="alamat" class="form-label">Alamat</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-geo-alt"></i></span>
                        <textarea class="form-control" id="alamat" name="alamat" rows="3" required><?= htmlspecialchars($undangan['alamat']) ?></textarea>
                    </div>
                </div>

                <div class="col-12">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="bi bi-save me-2"></i>Simpan Perubahan
                    </button>
                </div>
            </div>
        </form>
    </div>

    <!-- Bootstrap 5.3.2 JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
